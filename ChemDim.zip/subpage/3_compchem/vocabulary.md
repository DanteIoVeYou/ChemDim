乙烯氢-vinyl hydrogen

烯丙氢-allyl hydrogen

